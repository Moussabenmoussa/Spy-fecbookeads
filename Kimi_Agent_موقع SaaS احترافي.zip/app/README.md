# ToolKit Pro 🛠️

<p align="center">
  <img src="https://img.shields.io/badge/React-18-blue?style=for-the-badge&logo=react" alt="React 18">
  <img src="https://img.shields.io/badge/TypeScript-5.0-blue?style=for-the-badge&logo=typescript" alt="TypeScript">
  <img src="https://img.shields.io/badge/Tailwind-3.4-cyan?style=for-the-badge&logo=tailwindcss" alt="Tailwind CSS">
  <img src="https://img.shields.io/badge/Node.js-18-green?style=for-the-badge&logo=node.js" alt="Node.js">
  <img src="https://img.shields.io/badge/MongoDB-6.0-green?style=for-the-badge&logo=mongodb" alt="MongoDB">
</p>

<p align="center">
  <strong>منصة أدوات احترافية للمطورين والمصممين في العالم العربي</strong>
</p>

<p align="center">
  <a href="#-المميزات">المميزات</a> •
  <a href="#-التقنيات-المستخدمة">التقنيات</a> •
  <a href="#-النشر">النشر</a> •
  <a href="#-الاستخدام">الاستخدام</a>
</p>

---

## 🌟 نظرة عامة

**ToolKit Pro** هي منصة متكاملة تجمع أهم أدوات التطوير والتصميم والإنتاجية في مكان واحد. صممت خصيصاً للمطورين والمصممين في العالم العربي مع واجهة عربية سهلة الاستخدام ودعم كامل للغة العربية (RTL).

### 🎯 الرؤية

أن نكون المنصة العربية الأولى للأدوات الاحترافية، نساعد المطورين والمصممين على زيادة إنتاجيتهم وتبسيط سير عملهم.

---

## ✨ المميزات

### 🚀 أدوات متنوعة
- **أدوات التطوير**: منسق JSON، فاحص Regex، محول Base64، مضغط CSS
- **أدوات الأمان**: مولد كلمات المرور، مولد التجزئة، مشفر الروابط
- **أدوات التصميم**: منتقي الألوان، مولد النصوص، محلل الألوان
- **أدوات الوسائط**: ضاغط الصور، محول الصيغ
- **أدوات مساعدة**: محول الوحدات، مولد QR، والمزيد

### 🎨 تصميم عالمي
- واجهة مستخدم حديثة بتصميم عالمي المستوى
- دعم كامل للغة العربية (RTL)
- تصميم متجاوب مع جميع الأجهزة
- رسوم متحركة سلسة وتفاعلية
- وضع داكن وفاتح

### ⚡ أداء عالي
- تحميل سريع للصفحات
- معالجة فورية للبيانات
- لا حاجة للتسجيل للاستخدام
- 100% مجاني

### 🔒 أمان وموثوقية
- جميع العمليات تتم في المتصفح
- لا نخزن بيانات المستخدمين
- اتصال آمن HTTPS

---

## 🛠️ التقنيات المستخدمة

### Frontend
- **React 18** - مكتبة واجهات المستخدم
- **TypeScript** - لغة البرمجة
- **Tailwind CSS** - إطار العمل للتصميم
- **shadcn/ui** - مكونات واجهة المستخدم
- **Vite** - أداة البناء
- **Lucide React** - الأيقونات

### Backend
- **Node.js** - بيئة التشغيل
- **Express.js** - إطار العمل للـ API
- **MongoDB** - قاعدة البيانات
- **Mongoose** - ODM لـ MongoDB

### Deployment
- **Render** - منصة النشر
- **GitHub** - إدارة الكود المصدري

---

## 🚀 النشر

### المتطلبات
- Node.js >= 18
- MongoDB Atlas Account
- Render Account
- GitHub Account

### خطوات النشر على Render

#### 1. قاعدة البيانات (MongoDB Atlas)
1. أنشئ حساباً على [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. أنشئ cluster جديد
3. احصل على connection string
4. احفظها للاستخدام لاحقاً

#### 2. Backend API
1. سجل الدخول إلى [Render](https://render.com)
2. أنشئ Web Service جديد
3. اربطه بمستودع GitHub
4. اضبط الإعدادات:
   - **Build Command**: `cd backend && npm install`
   - **Start Command**: `cd backend && npm start`
5. أضف متغيرات البيئة:
   - `MONGODB_URI`: رابط قاعدة البيانات
   - `JWT_SECRET`: مفتاح سري للتوكن
   - `NODE_ENV`: production

#### 3. Frontend
1. أنشئ Static Site جديد
2. اربطه بنفس المستودع
3. اضبط الإعدادات:
   - **Build Command**: `npm install && npm run build`
   - **Publish Directory**: `dist`

### النشر المحلي

```bash
# Clone the repository
git clone https://github.com/yourusername/toolkitpro.git
cd toolkitpro

# Install frontend dependencies
npm install

# Install backend dependencies
cd backend
npm install
cd ..

# Setup environment variables
cp backend/.env.example backend/.env
# Edit backend/.env with your settings

# Seed the database
node backend/seed.js

# Run development server (frontend)
npm run dev

# Run backend server (in another terminal)
cd backend && npm start
```

---

## 📁 هيكل المشروع

```
toolkitpro/
├── src/                    # Frontend source code
│   ├── sections/          # Page sections
│   │   ├── Header.tsx
│   │   ├── Hero.tsx
│   │   ├── Tools.tsx
│   │   ├── Features.tsx
│   │   ├── Stats.tsx
│   │   ├── Contact.tsx
│   │   └── Footer.tsx
│   ├── components/        # UI components
│   ├── hooks/            # Custom hooks
│   ├── types/            # TypeScript types
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── backend/               # Backend API
│   ├── models/           # Database models
│   ├── routes/           # API routes
│   ├── middleware/       # Express middleware
│   ├── server.js         # Main server file
│   ├── seed.js           # Database seeder
│   └── package.json
├── dist/                 # Build output
├── public/               # Static assets
├── index.html
├── package.json
├── tailwind.config.js
├── tsconfig.json
├── vite.config.ts
├── render.yaml           # Render deployment config
└── README.md
```

---

## 📝 API Documentation

### Endpoints

#### Tools
- `GET /api/tools` - Get all tools
- `GET /api/tools/:id` - Get single tool
- `POST /api/tools/:id/use` - Increment tool usage
- `GET /api/tools/categories/list` - Get categories
- `GET /api/tools/popular/list` - Get popular tools

#### Contact
- `POST /api/contact` - Submit contact form
- `GET /api/contact` - Get all messages (Admin)

#### Users
- `POST /api/users/register` - Register new user
- `POST /api/users/login` - Login user
- `GET /api/users/profile` - Get user profile
- `POST /api/users/favorites` - Add to favorites
- `DELETE /api/users/favorites` - Remove from favorites

### Health Check
- `GET /api/health` - Check server status

---

## 🤝 المساهمة

نرحب بمساهماتكم! إذا كنت ترغب في المساهمة:

1. Fork المستودع
2. أنشئ فرعاً جديداً (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى الفرع (`git push origin feature/amazing-feature`)
5. افتح Pull Request

---

## 📄 الترخيص

هذا المشروع مرخص بموجب [MIT License](LICENSE).

---

## 👨‍💻 الفريق

صنع بـ ❤️ في المملكة العربية السعودية

---

## 📞 تواصل معنا

- **البريد الإلكتروني**: support@toolkitpro.com
- **تويتر**: [@ToolKitPro](https://twitter.com/toolkitpro)
- **الموقع**: [https://toolkitpro.com](https://toolkitpro.com)

---

<p align="center">
  <strong>⭐ لا تنسَ إعطاءنا نجمة إذا أعجبك المشروع!</strong>
</p>
